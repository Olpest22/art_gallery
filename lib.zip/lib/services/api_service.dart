import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/artwork.dart';

/// Ошибка с текстом, который не стыдно показать пользователю.
class ApiException implements Exception {
  final String message;
  ApiException(this.message);

  @override
  String toString() => message;
}

class ArtPage {
  final List<Artwork> items;
  final bool hasMore;
  ArtPage(this.items, this.hasMore);
}

class ApiService {
  static const _host = 'api.artic.edu';
  static const _fields =
      'id,title,artist_display,date_display,image_id,medium_display,'
      'place_of_origin,dimensions,description';

  Future<ArtPage> fetch({
    required int page,
    String query = '',
    int limit = 20,
  }) async {
    final q = query.trim();
    final isSearch = q.isNotEmpty;
    final params = <String, String>{
      'page': '$page',
      'limit': '$limit',
      'fields': _fields,
      if (isSearch) 'q': q,
    };
    final uri = Uri.https(
      _host,
      isSearch ? '/api/v1/artworks/search' : '/api/v1/artworks',
      params,
    );

    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode != 200) {
        throw ApiException(
            'Сервер ответил ошибкой (${res.statusCode}). Попробуй позже.');
      }
      final body = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;

      final iiif = (body['config'] as Map<String, dynamic>?)?['iiif_url'];
      if (iiif is String && iiif.isNotEmpty) Artwork.iiifBase = iiif;

      final data = (body['data'] as List).cast<Map<String, dynamic>>();
      final pagination = body['pagination'] as Map<String, dynamic>?;
      final totalPages = (pagination?['total_pages'] as num?)?.toInt() ?? page;

      // у части работ нет картинки — такие в галерее не нужны
      final items =
          data.map(Artwork.fromJson).where((a) => a.imageId != null).toList();
      return ArtPage(items, page < totalPages);
    } on ApiException {
      rethrow;
    } on TimeoutException {
      throw ApiException('Сервер слишком долго отвечает. Проверь интернет.');
    } on http.ClientException {
      throw ApiException('Нет соединения с интернетом.');
    } catch (_) {
      throw ApiException('Не получилось разобрать ответ сервера.');
    }
  }
}
