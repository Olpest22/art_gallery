class Artwork {
  /// Базовый адрес картинок (уже вместе с /2). Обновляется из ответа API (config.iiif_url).
  static String iiifBase = 'https://www.artic.edu/iiif/2';

  final int id;
  final String title;
  final String artist;
  final String? date;
  final String? imageId;
  final String? medium;
  final String? origin;
  final String? dimensions;
  final String? description;

  const Artwork({
    required this.id,
    required this.title,
    required this.artist,
    this.date,
    this.imageId,
    this.medium,
    this.origin,
    this.dimensions,
    this.description,
  });

  /// Первая строка из artist_display (там обычно "Имя\nНациональность, годы").
  String get artistName => artist.split('\n').first;

  String? imageUrl(int width) {
    if (imageId == null) return null;
    return '$iiifBase/$imageId/full/$width,/0/default.jpg';
  }

  factory Artwork.fromJson(Map<String, dynamic> json) {
    return Artwork(
      id: (json['id'] as num).toInt(),
      title: _clean(json['title']) ?? 'Без названия',
      artist: _clean(json['artist_display']) ?? 'Автор неизвестен',
      date: _clean(json['date_display']),
      imageId: json['image_id'] as String?,
      medium: _clean(json['medium_display']),
      origin: _clean(json['place_of_origin']),
      dimensions: _clean(json['dimensions']),
      description: _clean(json['description']),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'artist_display': artist,
        'date_display': date,
        'image_id': imageId,
        'medium_display': medium,
        'place_of_origin': origin,
        'dimensions': dimensions,
        'description': description,
      };

  /// Выкидывает HTML-теги и самые частые html-сущности.
  static String? _clean(dynamic v) {
    if (v is! String) return null;
    final s = v
        .replaceAll(RegExp(r'<[^>]*>'), '')
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .trim();
    return s.isEmpty ? null : s;
  }
}
